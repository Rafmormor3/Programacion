package mapa;

public enum Genero {
	MASCULINO, FEMENINO, NEUTRO, DESCONOCIDO;
}
